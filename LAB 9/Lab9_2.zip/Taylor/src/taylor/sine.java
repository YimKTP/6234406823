package taylor;

public class sine extends Taylor {

    private double sum;

    public sine(int k, double x) {
        super(k, x);
    }

    @Override
    public void printValue() {
        System.out.println("Value from Math.sin() is " + Math.sin(getValue()) + ".");
        System.out.println("Approximate value is " + getApprox() + ".");
    }

    @Override
    public double getApprox() {
        int cnt = 0;
        while (cnt < getIter()) {
            sum += (Math.pow(-1, cnt) * Math.pow(getValue(), 2 * cnt + 1)) / factorial(2*cnt + 1);
            cnt ++;
        }

        return sum;
    }
}
