package taylor;

public class expo extends Taylor {

    private double sum;

    public expo(int k, double x) {
        super(k, x);
    }

    @Override
    public void printValue() {
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + ".");
        System.out.println("Approximate value is " + getApprox() + ".");
    }

    @Override
    public double getApprox() {
        int cnt = 0;
        while (cnt < getIter()) {
            sum += (Math.pow(getValue(), cnt)) / factorial(cnt);
            cnt ++;
        }

        return sum;
    }
}
