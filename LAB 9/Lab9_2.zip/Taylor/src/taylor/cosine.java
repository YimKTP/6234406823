package taylor;

public class cosine extends Taylor {

    private double sum;

    public cosine(int k, double x) {
        super(k, x);
    }

    @Override
    public void printValue() {
        System.out.println("Value from Math.cos() is " + Math.cos(getValue()) + ".");
        System.out.println("Approximate value is " + getApprox() + ".");
    }

    @Override
    public double getApprox() {
        int cnt = 0;
        while (cnt < getIter()) {
            sum += (Math.pow(-1, cnt) * Math.pow(getValue(), 2 * cnt)) / factorial(2*cnt);
            cnt ++;
        }

        return sum;
    }
}
