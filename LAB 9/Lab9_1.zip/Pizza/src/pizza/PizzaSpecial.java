package pizza;

public class PizzaSpecial extends Pizza {

    private String special;

    public PizzaSpecial(String name, double price, String special) {
        super(name, price);
        this.special = special;
    }

    public String getSpecial() {
        return special;
    }

    @Override
    public String toString() {
        return "Name : " + getName() + "\nPrice : " + getPrice() + "\nSpecial : " + special;
    }
}
