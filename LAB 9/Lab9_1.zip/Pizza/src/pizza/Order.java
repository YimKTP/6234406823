package pizza;

import java.util.ArrayList;

public class Order {

    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    private double totalPrice;

    public Order(Customer customer) {
        this.c = customer;
        p = new ArrayList<>();
        cntOrder ++;
    }

    public void addPizza(Pizza pizza) {
        p.add(pizza);
    }

    public String getOrderDetail() {
        String result = "Order id : " + cntOrder + "\n" + c.getName() + " tel : " + c.getTel();
        int cnt = 0;
        if (c instanceof GoldCustomer) {
            result += " discount : " + ((GoldCustomer) c).getDiscount();
            for (Pizza pizza : p) {
                result += "\n" + pizza.getName() + " price : " + pizza.getPrice();
                if (pizza instanceof PizzaSpecial) {
                    result += " special : " + ((PizzaSpecial) pizza).getSpecial();
                }

                cnt ++;
            }
        }
        else {
            for (Pizza pizza : p) {
                result += "\n" + pizza.getName() + " price : " + pizza.getPrice();
                cnt ++;
            }
        }

        result += "\nTotal pieces : " + cnt + "\nTotal cost : " + calculatePayment();
        totalPrice = 0;
        return result;
    }

    public double calculatePayment() {
       if (c instanceof GoldCustomer) {
           for (Pizza pizza : p) {
               totalPrice += pizza.getPrice();
           }

           totalPrice -= totalPrice * (((GoldCustomer) c).getDiscount()/100);
       }
       else {
           for (Pizza pizza : p) {
               totalPrice += pizza.getPrice();
           }
       }

       return totalPrice;
    }
}
