package bus;

public interface Electric {
    final double LOW_VOLTAGE = 480;
    final double HIGH_VOLTAGE = 600;

    public abstract double getVoltage();
}
