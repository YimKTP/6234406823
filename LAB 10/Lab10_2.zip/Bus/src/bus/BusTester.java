package bus;

import java.util.ArrayList;

public class BusTester {

    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        Bus hybridBus = new Hybrid(45, 1.2, 600, 150, 1);
        arr.add(hybridBus);
        Bus CNGBus = new CNGBus(50, 1, 200, 2);
        arr.add(CNGBus);

        for (Bus bus : arr) {
            System.out.println("ID: " + bus.getID() + "\nEmission Tier: " + bus.getEmissionTier() + "\nAccel: " + bus.getAccel());
        }
    }
}
