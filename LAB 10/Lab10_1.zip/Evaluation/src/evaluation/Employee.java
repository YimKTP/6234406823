package evaluation;

public class Employee {

    private String name;
    private int salary;

    public Employee(String name) {
        this.name = name;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return (name + "\nsalary = " + salary );
    }
}
