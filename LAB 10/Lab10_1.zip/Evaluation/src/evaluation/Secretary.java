package evaluation;

public class Secretary extends Employee implements Evaluation {

    private int typingSpeed;
    private int[] score;
    private int sum = 0;

    public Secretary(String name, int salary, int[] score, int typingSpeed) {
        super(name);
        setSalary(salary);
        this.score = score;
        this.typingSpeed = typingSpeed;

    }

    @Override
    public double evaluate() {
        for (int score : score) {
            sum += score;
        }

        return sum;
    }

    @Override
    public char grade(double sumScore) {
        if (sumScore >= 90) {
            setSalary(18000);
            return 'P';
        }

        return 'F';
    }
}
