package evaluation;

public interface Evaluation {

    public abstract double evaluate();
    public abstract char grade(double sumScore);
}
