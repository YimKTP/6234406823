package evaluation;

public class Subject implements Evaluation {

    private String subjName;
    private int[] score;
    private double average;

    public Subject(String subjName, int[] score) {
        this.subjName = subjName;
        this.score = score;
    }

    @Override
    public double evaluate() {
        int sum = 0;
        int counter = 0;
        for (int score : score) {
            sum += score;
            counter ++;
        }

        average = sum / counter;
        return average;
    }

    @Override
    public char grade(double avgScore) {
        if (avgScore >= 70) {
            return 'P';
        }

        return 'F';
    }

    @Override
    public String toString() {
        return subjName;
    }
}
