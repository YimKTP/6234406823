package lab3_3;

import java.text.DecimalFormat;

public class CashRegisterTester {
    
    private static DecimalFormat df2 = new DecimalFormat("#.##");

    public static void main(String[] args) {
        CashRegister cash = new CashRegister(7);
        
        cash.recordPurchase(50);
        cash.recordPurchase(10);
        cash.recordTaxablePurchase(20);
        cash.enterPayment(100);
        
        System.out.println("Your change is " + df2.format(cash.getChange()));
    }
    
}
