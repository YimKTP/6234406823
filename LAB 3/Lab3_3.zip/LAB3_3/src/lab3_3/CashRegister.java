package lab3_3;

public class CashRegister {
    private double totalPrice = 0.0;
    private double paidAmount = 0.0;
    private double totalTax = 0.0;
    private final double taxRate;
    
    public CashRegister(double taxRate) {
        this.taxRate = taxRate;
    }
    
    public void recordPurchase(double price) {
        totalPrice += price;
    }
    
    public void recordTaxablePurchase(double price) {
        totalTax += price*(taxRate/100);
        totalPrice += price + (price*(taxRate/100));
    }
    
    public void enterPayment(double amount) {
        paidAmount += amount;
    }
    
    public double getTotalTax() {
        return totalTax;
    }
    
    public double getChange() {
        return (paidAmount - totalPrice);
    }
}
