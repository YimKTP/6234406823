package lab3_1;

public class InsectPopulation {
    
    private double population;
    
    public InsectPopulation(double startPopulation) {
        population = startPopulation;
    }
    
    public void breed() {
        population *= 2;
    }
    
    public void spray() {
        population -= population*0.1; 
    }
    
    public double getNumInsect() {
        return population;
    }
}
