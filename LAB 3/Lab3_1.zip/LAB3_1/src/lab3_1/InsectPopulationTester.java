package lab3_1;

import java.text.DecimalFormat;


public class InsectPopulationTester {
    
    private static DecimalFormat df2 = new DecimalFormat("#.##");
 
    public static void main(String[] args) {
       
        InsectPopulation insect = new InsectPopulation(10);
        
        for(int i=0; i<=2; i++) {
            insect.breed();
            insect.spray();
            
            System.out.println("Number of insects: " + df2.format(insect.getNumInsect()));
        }
    }
    
}
