package lab3_2;

public class Letter {
    
    private final String sender;
    private final String receiver;
    private String textBody = "";
    
    public Letter(String from, String to) {
        sender = from;
        receiver = to;
    }
    
    public void addLine(String line) {
        textBody += (line + "\n");
    }
    
    public String getText() {
        return ("Dear " + receiver + ":\n\n" + textBody + "\nSincerely,\n\n" + sender);
    }
}
