package lab4_1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class SodaCanTester {
    
    public static void main(String[] args) {
        
        DecimalFormat df2 = new DecimalFormat("##.##");
        double height;
        double diameter;
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter height: ");
        height = scan.nextDouble();
        System.out.print("Enter diameter: ");
        diameter = scan.nextDouble();
        
        SodaCan can1 = new SodaCan(height, diameter);
        
        System.out.println("Volume: " + df2.format(can1.getVolume()));
        System.out.println("Surface Area: " + df2.format(can1.getSurfaceArea()));
    }
    
}
