package lab4_1;

public class SodaCan {
    
    private final double height;
    private final double radius;
    
    public SodaCan(double height, double diameter) {
        this.height = height;
        this.radius = diameter / 2.0;
    }
    
    public double getVolume() {
        return (Math.PI * (radius*radius) * height);
    }
    
    public double getSurfaceArea() {
        return (2 * Math.PI * radius * (radius + height));
    }
}
