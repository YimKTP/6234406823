package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static final String RESULT = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sendMessage(View view) {
        Intent intent = new Intent(this, DisplayResultActivity.class);
        EditText editText = (EditText) findViewById(R.id.yearInput);
        String message = editText.getText().toString();
        String textPrefix = "In " + message + " the easter day is on ";
        EasterDayCalculation calculation = new EasterDayCalculation(message);
        intent.putExtra(RESULT, textPrefix + calculation.getEasterDay());
        startActivity(intent);
    }
}
