package lab4_3;

public class TimeInterval {
    private final int startTime, endTime, startHr, startMin, endHr,endMin, startInMin, endInMin;
    
    public TimeInterval(int startTime, int endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
        
        startHr = this.startTime/100;
        startMin = this.startTime%100;
        endHr = this.endTime/100;
        endMin =this.endTime%100;
        
        startInMin = startMin + (startHr*60);
        endInMin = endMin + (endHr*60);
    }
    
    public int getHours() {
        return ((int) (endInMin - startInMin)/60);
    }
    
    public int getMinutes() {
        return ((endInMin - startInMin) % 60);
    }
}
