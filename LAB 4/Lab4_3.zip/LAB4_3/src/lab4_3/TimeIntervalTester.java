package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {

    public static void main(String[] args) {
        
        int startTime, endTime;
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter start time: ");
        startTime = scan.nextInt();
        System.out.print("Enter end time: ");
        endTime = scan.nextInt();
        
        TimeInterval time = new TimeInterval(startTime, endTime);
        System.out.printf("%d hours %d minutes %n", time.getHours() ,time.getMinutes());
    }
    
}
