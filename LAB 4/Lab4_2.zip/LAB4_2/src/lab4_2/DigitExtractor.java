package lab4_2;

public class DigitExtractor {
    private final int number;
    private int counter = 1;
    
    public DigitExtractor(int anInteger) {
        this.number = anInteger;
    }
    
    public int nextDigit() {
        int temp = (int) (number % Math.pow(10, counter) / Math.pow(10, counter-1));
        counter += 1;
        return (temp);
    }
}
