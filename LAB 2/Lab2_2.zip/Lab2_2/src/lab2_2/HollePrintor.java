package lab2_2;

public class HollePrintor {

    public static void main(String[] args) {
        String st = "Hello, World!";
        
        st = st.replace('e', 'x');
        st = st.replace('o', 'e');
        st = st.replace('x', 'o');
        
       System.out.println(st);
    }
    
}
