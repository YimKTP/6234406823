package intersectionprinter;

import java.awt.Rectangle;
import java.util.Random;

public class IntersectionPrinter {

    public static void main(String[] args) {
        Random generator = new Random();
        Rectangle r1 = new Rectangle(generator.nextInt(51), generator.nextInt(51), generator.nextInt(51), generator.nextInt(51));
        Rectangle r2 = new Rectangle(generator.nextInt(51), generator.nextInt(51), generator.nextInt(51), generator.nextInt(51));
        Boolean isEmpty;
        
        Rectangle r3 = r1.intersection(r2);
        
        System.out.println(r1);
        System.out.println(r2);
        
        isEmpty = r3.isEmpty();
        
        System.out.println("Is the intersected rectangle empty?:" + isEmpty);
    }
    
}
