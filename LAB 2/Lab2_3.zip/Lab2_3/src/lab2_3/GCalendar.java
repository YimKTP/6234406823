package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class GCalendar {

    public static void main(String[] args) {
        GregorianCalendar toDay = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2000, Calendar.AUGUST, 25);
        
        toDay.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        
        System.out.println("" + toDay.get(Calendar.DAY_OF_WEEK) + " " + toDay.get(Calendar.DAY_OF_MONTH) + " " + (1 + toDay.get(Calendar.MONTH)) + " " + toDay.get(Calendar.YEAR));
        System.out.println("" + myBirthday.get(Calendar.DAY_OF_WEEK) + " " + myBirthday.get(Calendar.DAY_OF_MONTH) + " " + (1 + myBirthday.get(Calendar.MONTH)) + " " + myBirthday.get(Calendar.YEAR));
    }
    
}
