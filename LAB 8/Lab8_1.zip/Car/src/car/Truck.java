package car;

public class Truck extends Car {
    private double M_weight, weight;

    public Truck(double gas, double efficiency, double M_weight, double weight) {
        super(gas, efficiency);
        this.M_weight = M_weight;

        if (weight > M_weight) {
            this.weight = M_weight;
        } else {
            this.weight = weight;
        }
    }

    @Override
    public void drive(double distance) {
        double loss = distance/getEfficiency();

        if (weight > 20) {
            loss *= 1.3;
        } else if (weight > 10) {
            loss *= 1.2;
        } else if (weight >= 1) {
            loss *= 1.1;
        }

        if (loss > getGas()) {
            System.out.println("You cannot drive too far, please add gas");
        } else {
            addGas(-loss);
        }
    }
}
