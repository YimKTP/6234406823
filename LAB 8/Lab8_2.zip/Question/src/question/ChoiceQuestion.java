package question;

import java.util.ArrayList;

public class ChoiceQuestion extends Question {
    ArrayList<String> choices = new ArrayList<>();
    public ChoiceQuestion(String text){
        super(text);
    }

    public void addChoice(String choice, boolean correct){
        choices.add(choice);
        if (correct){
            setAnswer(choice);
        }
    }
    @Override
    public void display(){
        super.display();
        int i=0;
        for(String element : choices){
            System.out.println(++i+": " + element);
        }
    }
    @Override
    public boolean checkAnswer(String response){
        return choices.get(Integer.parseInt(response)-1) == getAnswer();
    }
}
