import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {

    private ArrayList<Product> queue = new ArrayList<Product>();
    private double totalPrice = 0;

    @Override
    public void enqueue(Object o) {
        queue.add((Product) o);
        System.out.println(((Product) o).getName() + " is added in queue");
    }

    @Override
    public void dequeue() {
        totalPrice += queue.get(0).getPrice();
        queue.remove(0);
    }

    public double getAmount() {
        return totalPrice;
    }
}
