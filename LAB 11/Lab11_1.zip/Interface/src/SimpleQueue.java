public interface SimpleQueue {
    void enqueue(Object o);
    void dequeue();
}
