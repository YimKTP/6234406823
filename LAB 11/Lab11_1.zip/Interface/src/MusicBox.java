import java.util.ArrayList;

public class MusicBox implements SimpleQueue {

    private ArrayList<String> queue = new ArrayList<String>();

    @Override
    public void enqueue(Object o) {
        queue.add((String) o);
        System.out.println((String) o + " is added in queue");
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing " + queue.get(0));
        queue.remove(0);
    }
}
