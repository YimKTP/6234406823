public interface CanWalk {
    void walk(Terrain terrain);
    void run(Terrain terrain);
}
