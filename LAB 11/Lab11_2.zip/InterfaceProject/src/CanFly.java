public interface CanFly {
    void fly(Terrain terrain);
}
