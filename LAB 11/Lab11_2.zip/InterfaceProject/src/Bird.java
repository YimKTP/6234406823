public class Bird extends Animal implements CanFly, CanWalk {

    Terrain terrain;

    public Bird(String name) {
        super(name);
    }

    @Override
    public void fly(Terrain terrain) {
        if (terrain instanceof Pool){
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") can fly on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
        else if(terrain.canMove(this)) {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") can fly over " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        } else {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot fly over " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
    }

    @Override
    public void walk(Terrain terrain) {
        if (terrain instanceof Pool){
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot walk on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
        else if (terrain instanceof Sky){
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot walk on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
        else if(terrain.canMove(this)) {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") can walk on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        } else {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot walk on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
    }

    @Override
    public void run(Terrain terrain) {
        if (terrain instanceof Pool){
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot run on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
        else if (terrain instanceof Sky){
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot run on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
        else if(terrain.canMove(this)) {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") can run on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        } else {
            System.out.println(this.getName() +"(" +this.getClass().getSimpleName()
                    +") cannot run on " + terrain.getName() + "("+terrain.getClass().getSimpleName()+")");
        }
    }
}
