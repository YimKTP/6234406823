module Line {
	requires java.desktop;
}