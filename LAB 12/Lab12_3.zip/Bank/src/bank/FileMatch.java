package bank;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch {

    public static void main(String[] args) throws IOException {
        ArrayList<AccountRecord> accountRecordArrayList = new ArrayList();
        ArrayList<TransactionRecord> transactionRecordArrayList = new ArrayList();

        try(Scanner masterFileScanner = new Scanner(new File("master.txt"));
            Scanner transFileScanner = new Scanner(new File("trans.txt"));
            RandomAccessFile randomAccessFile = new RandomAccessFile(new File("newMaster.dat"),"rw")){
            int accCnt = 0;

            while (masterFileScanner.hasNext()) {
                String input = masterFileScanner.nextLine();
                String[] s = input.split(" ");
                int acctNo = Integer.parseInt(s[0]);
                String name = s[1]+" "+s[2];
                double balance = Double.parseDouble(s[3]);
                accountRecordArrayList.add(new AccountRecord(acctNo, name, balance));
            }

            while (transFileScanner.hasNext()) {
                String input = transFileScanner.nextLine();
                String[] s = input.split(" ");
                int acctNo = Integer.parseInt(s[0]);
                double amount = Double.parseDouble(s[1]);
                transactionRecordArrayList.add(new TransactionRecord(acctNo, amount));
            }

            for (AccountRecord a : accountRecordArrayList) {
                for(TransactionRecord t: transactionRecordArrayList){
                    a.combine(t);
                }
            }

            for (AccountRecord a : accountRecordArrayList) {
                randomAccessFile.writeInt(a.getAcctNo());
                long keep = randomAccessFile.getFilePointer();
                long i = 0;
                if(i < 30){
                    randomAccessFile.writeChars(a.getName());
                    long keep2 = randomAccessFile.getFilePointer();
                    i = keep2 - keep;
                    while(i < 30){
                        randomAccessFile.writeChar(' ');
                        i += 2;
                    }

                }
                randomAccessFile.writeDouble(a.getBalance());
                randomAccessFile.writeInt(a.getTransCnt());
                randomAccessFile.writeChar('\n');
                accCnt++;
            }
            long n = 0;
            int cnt = 0;
            double balance = 0;
            int transact = 0;
            randomAccessFile.seek(0);

            while(n < (48*accCnt)){
                randomAccessFile.seek(randomAccessFile.getFilePointer());
                randomAccessFile.readInt();
                randomAccessFile.readLine();
                randomAccessFile.seek(randomAccessFile.getFilePointer());
                randomAccessFile.seek(randomAccessFile.getFilePointer()-14);
                balance += randomAccessFile.readDouble();

                int t = randomAccessFile.readInt();

                if(t == 0){
                    transact++;
                }

                randomAccessFile.readLine();
                n = randomAccessFile.getFilePointer();
                cnt++;
            }

            System.out.println("Total Account Record : "+cnt);
            System.out.println("Total balance : " + balance);
            System.out.println("No transaction : " + transact + " account.");
            randomAccessFile.close();
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }

    }
}
