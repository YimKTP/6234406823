package wordfinder;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class WordFinder {

    private static ArrayList<String> list = new ArrayList<>();

    public static void main(String[] args) {
        Scanner keyboardInput = new Scanner(System.in);

        try {
            File wordListFile = new File("wordlist.txt");
            Scanner wordListScanner = new Scanner(wordListFile);

            while (wordListScanner.hasNextLine()) {
                String temp = wordListScanner.nextLine();
                list.add(temp);
            }

            System.out.println("Enter a sentence: ");

            String input = keyboardInput.nextLine();
            String[] stringsInput = input.split(" ");
            String word = "";

            for (String string: stringsInput) {
                if (!list.contains(string)) {
                    word += string + " ";
                }
            }

            if (word.length() == 0) {
                word = "N/A";
            }

            System.out.println("Word not contained: " + word);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
