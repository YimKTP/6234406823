package writefile;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWriting {
    private static int character;
    private static int word;
    private static int line;

    public static void main(String[] args) {
        Scanner keyboardInput = new Scanner(System.in);
        File textFile = new File("textFile.txt");
        try {
            FileWriter writer = new FileWriter("textFile.txt");
            String textIn = keyboardInput.nextLine();

            while (!textIn.equalsIgnoreCase("quit")) {
                writer.write(textIn);

                String[] temp = textIn.split(" ");
                character += textIn.length();
                word += temp.length;
                line ++;

                textIn = keyboardInput.nextLine();
            }

            System.out.println("Total characters: " + character);
            System.out.println("Total words: " + word);
            System.out.println("Total lines: " + line);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
