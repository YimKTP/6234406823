package magicsquare;

public class MagicSquareTester {

	public static void main(String[] args) {
		MagicSquare square = new MagicSquare(5);
        square.Play();
        square.toString();
	}

}
