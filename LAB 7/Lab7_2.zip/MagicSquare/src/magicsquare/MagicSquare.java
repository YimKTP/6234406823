package magicsquare;

public class MagicSquare {
	
	private int length;
    private int [][] square;
    
    public MagicSquare (int length) {
        this.length = length;
        square = new int[length][length];
    }
    
    public void Play () {
        square[length-1][length/2] = 1; 
        int k = 2, i = length-1, j = length/2;
        
       for (int count = 0 ; count < (length*length) - 1; count++) {         
               if (i+1 > length-1 && j+1 > length-1 ) {
                    if (square[0][0] != 0) {
                        i--;
                        if (i<0) {
                            i = length-1;   
                        }
                        
                        square[i][j] = k;
                    }
                }
                else if (i+1 > length-1) {
                    if (square[0][j+1] == 0) {
                        i = 0;
                        j++; 
                        square[i][j] = k;
                    }
                    else {
                        i--;
                        if (i<0) {
                            i = length-1;
                        }
                        square[i][j] = k;
                    }
                }
                else if (j+1 > length - 1) {
                    if (square[i+1][0] == 0) {
                        j = 0;
                        i++;
                        square[i][j] = k;
                    }
                    else {
                        i--;
                        if (i<0) {
                            i = length-1;
                        }
                        square[i][j] = k;
                    } 
                }
              else {
                if (square[i+1][j+1] == 0) {
                    i++;
                    j++;
                    square[i][j] = k;  
                }
                else {
                    i--;
                    if (i<0) {
                        i = length-1;
                         if (square[0][0] != 0)
                                i--;
                    }
                    square[i][j] = k;      
                }      
            }
            k++;
        }
    }
    
    public String toString () {
        int count = 0;
        
        for (int [] i : square) {
        	
            for (int j : i) {
                count++;
                System.out.print(j + "\t");
                
                if (count > length-1) {
                    System.out.print("\n");
                    count = 0; 
                }
            }
        }   
        
        return (null);
    }
}
