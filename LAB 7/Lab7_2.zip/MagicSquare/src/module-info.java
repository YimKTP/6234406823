module MagicSquare {
}