package purse;

import java.util.Scanner;

public class PurseTester {
	
	public static void main(String[] args) {
		Purse purse1 = new Purse();
        Purse purse2 = new Purse();
        Scanner in = new Scanner(System.in);
        
        System.out.println("Test addCoin method");
        System.out.print("Enter a coin name, Q or q to exit: ");
        String name = in.nextLine();
        
        while (!("Q".equals(name) || "q".equals(name))) {
            purse1.addCoin(name);
            System.out.print("Enter a coin name, Q or q to exit: ");
            name = in.nextLine();
        }
        
        System.out.println("Test toString method");
        System.out.println(purse1.toString());
        System.out.println("Test reverse method");
        System.out.println(purse1.reverse());
        System.out.println("Test transfer method");
        System.out.print("Enter a coin name, Q or q to exit: ");
        String n = in.nextLine();
        
        while (!("Q".equals(n) || "q".equals(n))) { 
            purse2.addCoin2(n);
            System.out.print("Enter a coin name, Q or q to exit: ");
            n = in.nextLine();
        }
        purse1.transfer(purse2);
        System.out.println("Test sameContents method");
        System.out.println("These two purse the same: " + purse1.sameContents(purse2));
        System.out.println("Test sameCoins method");
        System.out.println("These two purse the same: " + purse1.sameCoins(purse2));
	}
}
