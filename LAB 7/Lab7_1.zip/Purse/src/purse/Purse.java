package purse;

import java.util.ArrayList;

public class Purse {
	
	private ArrayList<String> coin = new ArrayList<>();
	private ArrayList<String> coin2 = new ArrayList<>();
	
	public void addCoin(String coinName) {
		coin.add(coinName);
	}
	
	public String toString() {
		String temp = "";
		for (int i = 0; i < coin.size(); i++) {
			if (i > 0) {
				temp = temp + ",";
			}
			
			temp = temp + coin.get(i);
		}
		
		temp = "[" + temp + "]";
		return (temp);
	}
	
	public ArrayList<String> reverse() {
		for (int i = 0, j = coin.size() - 1; i < j; i++) {
			coin.add(i, coin.remove(j));
		}
		
		return (coin);
	}
	
	public void transfer(Purse other) {
		for (int i = 0;i<coin.size(); i++) {
	          other.coin2.add(coin.get(i));                
	       }
		
		for (int i = 0;i<coin.size(); i++) {
	          coin.remove(i);                             
	       }
		
		coin.remove(0);
		System.out.println("The first purse: " + coin + " The second purse: " + other.coin2);
	}
	
	public boolean sameContents(Purse other) {
		boolean value = false;
		
		if(coin.equals(other.coin2)) {
			value = true;
	       }
		
		return (value);
	}
	
	public boolean sameCoins(Purse other) {
		String temp = "";
		
        for (int count = 1; count < Purse.this.coin.size() ; count++ ) {
           for (int i =1; i< Purse.this.coin.size(); i++) {
               if (Purse.this.coin.get(i).compareTo(Purse.this.coin.get(i-1)) < 0) {
                  temp = Purse.this.coin.get(i);
                  
                  Purse.this.coin.set(i,Purse.this.coin.get(i-1) );
                  Purse.this.coin.set(i-1,temp);
               } 
           }
       }
        
        for (int count = 1; count < other.coin2.size() ; count++ ) {
           for (int i =1; i< other.coin2.size(); i++) {
               if (other.coin2.get(i).compareTo(other.coin2.get(i-1)) < 0) {
                   temp = other.coin2.get(i);
                   
                   other.coin2.set(i,other.coin2.get(i-1) );
                   other.coin2.set(i-1,temp); 
               }
           }
        }
        
        boolean value = false;
        
        if (coin.equals(other.coin2)) {
          value = true;
        }
      return value;
	}
	
	public ArrayList<String> addCoin2(String coinName) {
		coin2.add(coinName);
		return (coin2);
	}
}
