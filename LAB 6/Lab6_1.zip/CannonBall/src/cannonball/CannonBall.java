package cannonball;

public class CannonBall {
	
	private double initV, simS, simT, keepInitV;
	public static final double g = 9.81;
	
	public CannonBall(double initV) {
		this.initV = initV;
		this.keepInitV = initV;
	}
	
	public void simulatedFlight() {
		double t = 0.01;
		int count = 0;
		double deltaS = 0;
		int c = 0;
		
		while (initV > 0) {
			deltaS = initV * t;
			simS = simS + deltaS;
			initV = initV - (g * t);
			count += 1;
			
			if (count % 100 == 0) {
				c += 1;
				System.out.printf("distance on " + c + " sec: %.3f\n", simS);
			}
			
			simT = count;
		}
		
		simT = simT / 100;
		System.out.printf("Final distance: %.3f Total time: %.2f \n", simS, simT);
	}
	
	/* จำเป็นต้องเปลี่ยน method นี้ให้เป็น String เนื่องจากโจทย์บังคับให้  Tester เป็น 
	 * System.out.println(ball.calculusFlight(ball.getSimulatedTime()));
	 * ซึ่งผลรับที่ออกมาจะเป็นตัวเลขอย่างเดียวไม่ตรงกับผลลัพธ์ที่กำหนดในตัวอย่างการรันว่าต้องมีข้อความ
	 * Distance from calculus equation:
	 * ขึ้นมาก่อน จึงจำเป็นต้องแก้อย่างใดอย่างหนึ่ง ไม่แก้ method ให้ return type เป็น String ก็ต้องแก้ใน Tester class ให้เป็น
	 * System.out.printf("Distance from calculus equation: %.3f", ball.calculusFlight(ball.getSimulatedTime());
	 */
	public String calculusFlight(double t) {
		double distance = (-0.5 * 9.81 * (t*t)) + (keepInitV * t);
		return ("Distance from calculus equation: " + distance);
	}
	
	public double getSimulatedTime() {
		return (simT);
	}
	
	public double getSimulatedDistance() {
		return (simS);
	}
}
