module RockPaperScissor {
}